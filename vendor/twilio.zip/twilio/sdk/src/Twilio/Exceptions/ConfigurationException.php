<?php


namespace Twilio\Exceptions;


class ConfigurationException extends TwilioException {

}